package com.feasycom.feasyblue.logic

enum class AtCommand {
    NONE,GET_DHCP, SET_DHCP, GET_DNS, SET_DNS, GET_IP, SET_IP, SET_GW, SET_MASK, SET_NETWORK, GET_VERSION, OTA, RESET
}