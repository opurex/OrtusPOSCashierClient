package com.feasycom.feasyblue.interfaces

interface ICommandCallback {

    fun update(i: Int)
}