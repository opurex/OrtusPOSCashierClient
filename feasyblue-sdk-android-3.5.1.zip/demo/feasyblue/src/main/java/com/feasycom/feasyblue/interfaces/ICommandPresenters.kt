package com.feasycom.feasyblue.interfaces

interface ICommandPresenters {

    fun plus()
    fun minus()

}