package com.feasycom.ble.sdk;

public interface BindStatusCallback {
   void onBindStatus(boolean var1);
}
