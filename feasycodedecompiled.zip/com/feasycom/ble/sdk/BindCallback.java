package com.feasycom.ble.sdk;

public interface BindCallback {
   void onBindResult(boolean var1);
}
