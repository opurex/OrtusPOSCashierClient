package com.example.scaler;

import com.example.data.St_Dialog06;

public interface AclasDialogListener {
   void onRecvMsg(St_Dialog06 var1);
}
