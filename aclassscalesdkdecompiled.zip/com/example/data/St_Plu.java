package com.example.data;

public class St_Plu {
   public int m_iIndex;
   public int m_iPrice;

   public St_Plu(int arg0, int arg1) {
      this.m_iIndex = arg0;
      this.m_iPrice = arg1;
   }

   public St_Plu() {
   }
}
