package com.example.data;

public class St_PSData {
   public double dPrice;
   public double dAmount;
   public int iKeyVal;
   public int iDotPrice;
   public int iDotAmount;

   public void setData(St_PSData arg0) {
      this.dPrice = arg0.dPrice;
      this.dAmount = arg0.dAmount;
      this.iKeyVal = arg0.iKeyVal;
      this.iDotAmount = arg0.iDotAmount;
      this.iDotPrice = arg0.iDotPrice;
   }
}
